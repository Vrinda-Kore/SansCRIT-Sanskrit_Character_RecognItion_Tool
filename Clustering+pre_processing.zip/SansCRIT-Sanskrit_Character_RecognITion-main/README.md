# SansCRIT-Sanskrit_Character_RecognITion

The benchmark dataset can be found at: [https://drive.google.com/file/d/1hkgVnwbTPeVdj2AXmk9Z5IFt0S7Eieq8/view?usp=sharing]
